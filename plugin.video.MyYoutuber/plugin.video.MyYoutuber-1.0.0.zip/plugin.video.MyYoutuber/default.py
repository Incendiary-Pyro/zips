
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json,threading,requests

Addon = xbmcaddon.Addon(id='plugin.video.MyYoutuber')
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'

import socket
global list_index
list_index=111
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
save_file=os.path.join(user_dataDir,"fav.txt")
socket.setdefaulttimeout(30.0)
ACTION_PLAYER_STOP = 13
lang=xbmc.getLanguage(0)
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
class UpNext(xbmcgui.WindowXMLDialog):
    item = None
    cancel = False
    watchnow = False
    
    progressStepSize = 0
    currentProgressPercent = 100

    def __init__(self, *args, **kwargs):
        logging.warning('INIT UPNEXT')
        from platform import machine
        global list_index
        list_index=111
        OS_MACHINE = machine()
        self.closenow=0
        
        self.action_exitkeys_id = [10, 13]
        logging.warning('INIT UPNEXT0')
        self.progressControl = None
        if OS_MACHINE[0:5] == 'armv7':
            xbmcgui.WindowXMLDialog.__init__(self)
        else:
            xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        logging.warning('INIT UPNEXT2')
        
   
    def background_task(self):
        global list_index
        t=int(self.time_c)*10
        counter_close=0
        self.progressControl = self.getControl(3014)
        e_close=0
        before_end=int(Addon.getSetting("before_end2"))*10
        counter_close2=before_end
        while(t>30):
            self.label=self.getControl(3015)
            self.label.setLabel(('Next in %s')%str(int(counter_close2)/10))
            
            counter_close2-=1
            if counter_close2==0:
                t=0
                break
            self.currentProgressPercent=int((counter_close2*100)/before_end)
       
            self.progressControl.setPercent(self.currentProgressPercent)
            xbmc.sleep(100)
            t-=1
            if self.closenow==1:
                break
        if self.closenow==0:
            list_index=self.list.getSelectedPosition()        
        self.close()
    def onInit(self):
        self.time_c=0
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        
        
            
        self.list = self.getControl(3000)
        self.but = self.getControl(3012)
        for it in self.item['list']:
         
          
          liz   = xbmcgui.ListItem(it.split('$$$$$$$')[0])
          self.list.addItem(liz)
       
        
        self.setFocus(self.but)
        logging.warning('INIT UPNEXT1')
        Thread(target=self.background_task).start()
        self.setInfo()
        self.prepareProgressControl()

    def setInfo(self):
        logging.warning('INIT UPNEXT2')
        episodeInfo=''
        #episodeInfo = str(self.item['season']) + 'x' + str(self.item['episode']) + '.'
        if self.item['rating'] is not None:
            rating = str(round(float(self.item['rating']), 1))
        else:
            rating = None

        if self.item is not None:
            self.setProperty(
                'fanart', self.item['art'].get('tvshow.fanart', ''))
            self.setProperty(
                'landscape', self.item['art'].get('tvshow.landscape', ''))
            self.setProperty(
                'clearart', self.item['art'].get('tvshow.clearart', ''))
            self.setProperty(
                'clearlogo', self.item['art'].get('tvshow.clearlogo', ''))
            self.setProperty(
                'poster', self.item['art'].get('tvshow.poster', ''))
            self.setProperty(
                'thumb', self.item['art'].get('thumb', ''))
            self.setProperty(
                'plot', self.item['plot'])
            self.setProperty(
                'tvshowtitle', self.item['showtitle'])
            self.setProperty(
                'title', self.item['title'])
            self.setProperty(
                'season', str(self.item['season']))
            self.setProperty(
                'episode', str(self.item['episode']))
            self.setProperty(
                'seasonepisode', episodeInfo)
            self.setProperty(
                'year', str(self.item['firstaired']))
            self.setProperty(
                'rating', rating)
            self.setProperty(
                'playcount', str(self.item['playcount']))

    def prepareProgressControl(self):
        logging.warning('INIT UPNEXT3')
        # noinspection PyBroadException
        try:
            self.progressControl = self.getControl(3014)
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setItem(self, item):
        self.item = item

    def setProgressStepSize(self, progressStepSize):
        self.progressStepSize = progressStepSize

    def updateProgressControl(self):
        # noinspection PyBroadException
        try:
            self.currentProgressPercent = self.currentProgressPercent - self.progressStepSize
         
            self.progressControl = self.getControl(3014)
           
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setCancel(self, cancel):
        self.cancel = cancel

    def isCancel(self):
        return self.cancel

    def setWatchNow(self, watchnow):
        self.watchnow = watchnow

    def isWatchNow(self):
        return self.watchnow

    def onFocus(self, controlId):
        pass

    def doAction(self):
        pass

    def closeDialog(self):
        self.close()

    def onClick(self, control_id):
        global list_index
        
        if control_id == 3012:
            # watch now
            list_index=999
            self.setWatchNow(True)
            self.closenow=1
            self.close()
            
        elif control_id == 3013:
            # cancel
            list_index=888
            self.setCancel(True)
            self.closenow=1
            self.close()
        elif control_id == 3000:
            index = self.list.getSelectedPosition()        
            list_index=index
            self.closenow=1
            self.close()
        pass

    def onAction(self, action):
        
        if action == ACTION_PLAYER_STOP:
            self.closenow=1
            self.close()
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
  
        ok=True
        menu_items=[]
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        if mode==4 and name!='Search':
           menu_items.append(('[COLOR lightblue][I]Remove[/I][/COLOR]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&name=%s&mode=6')%(sys.argv[0],name)))
   
       
        liz.addContextMenuItems(menu_items, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok
def utf8_urlencode(params):
    import urllib as u
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in params.items():
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, long, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return u.urlencode(params.items()).decode('utf-8')
def addNolink( name, url,mode,isFolder,fan='DefaultFolder.png', iconimage="DefaultFolder.png",plot=' ',year=' ',generes=' ',rating=' ',trailer=' ',original_title=' '):
 

            name='[COLOR lightblue][I]'+name+'[/I][/COLOR]'
            params={}
            params['name']=name
            params['iconimage']=iconimage
            params['fanart']=fan
            params['description']=plot
            params['url']=url
            params['original_title']=original_title
            
            all_ur=utf8_urlencode(params)
            u=sys.argv[0]+"?&mode="+str(mode)+'&'+all_ur
           
            video_data={}
            video_data['title']=name
            
            
            if year!='':
                video_data['year']=year
            if generes!=' ':
                video_data['genre']=generes
            video_data['rating']=str(rating)
        
            video_data['poster']=fan
            video_data['plot']=plot
            if trailer!='':
                video_data['trailer']=trailer
            
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

            liz.setInfo(type="Video", infoLabels=video_data)
            liz.setProperty( "Fanart_Image", fan )
            liz.setProperty("IsPlayable","false")
            art = {}
            art.update({'poster': iconimage})
            liz.setArt(art)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addLink( name, url,mode,isFolder, iconimage,description):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title":  name, "Plot": description   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def read_site_html(url):
    import requests
    logging.warning(url)

    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': '%s;q=0.8,en-US;q=0.5,en;q=0.3'%lang,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
 
    x=requests.get(url, headers=headers).text
    if 'ytInitialData' not in x:
      x=requests.get(url, headers=headers).text
    return x.encode('utf8')

def read_site_html2(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html



def pop_youtube_data(name,url):

    
    html=read_site_html(url)

    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(html)

    json_data=json.loads(match[0]+'}')
    
    for value in json_data['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents']:
       
       for items in value['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']:
        new_key=items
       '''
       if 'expandedShelfContentsRenderer' in value['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']:
          new_key='expandedShelfContentsRenderer'
       else:
         new_key='horizontalListRenderer'
       '''
       for val in value['itemSectionRenderer']['contents'][0]['shelfRenderer']['content'][new_key]['items']:
         if 'gridRadioRenderer' in val:
             if 'playlistId' in val['gridRadioRenderer']:
               
               playid='playlistId@@@@'+val['gridRadioRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['gridRadioRenderer']['videoId']
             
             image=val['gridRadioRenderer']['thumbnail']['thumbnails'][0]['url']
             name=val['gridRadioRenderer']['title']['simpleText']
             if 'videoCountText' in val['gridRadioRenderer']:
               plot=val['gridRadioRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         elif 'gridVideoRenderer' in val:
             if 'playlistId' in val['gridVideoRenderer']:
               
               playid='playlistId@@@@'+val['gridVideoRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['gridVideoRenderer']['videoId']
             
             image=val['gridVideoRenderer']['thumbnail']['thumbnails'][0]['url']
             
             if 'simpleText' in val['gridVideoRenderer']['title']:
                name=val['gridVideoRenderer']['title']['simpleText']
             elif 'runs' in val['gridVideoRenderer']['title']:
                name=val['gridVideoRenderer']['title']['runs'][0]['text']
             else:
                name='Unknow'
                
             if 'videoCountText' in val['gridVideoRenderer']:
               plot=val['gridVideoRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         elif 'gridMovieRenderer' in val:
             if 'playlistId' in val['gridMovieRenderer']:
               
               playid='playlistId@@@@'+val['gridMovieRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['gridMovieRenderer']['videoId']
             
             image=val['gridMovieRenderer']['thumbnail']['thumbnails'][0]['url']
             
             if 'simpleText' in val['gridMovieRenderer']['title']:
                name=val['gridMovieRenderer']['title']['simpleText']
             elif 'runs' in val['gridMovieRenderer']['title']:
                name=val['gridMovieRenderer']['title']['runs'][0]['text']
             else:
                name='Unknow'
                
             if 'videoCountText' in val['gridMovieRenderer']:
               plot=val['gridMovieRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         elif 'videoRenderer' in val:
             if 'playlistId' in val['videoRenderer']:
               
               playid='playlistId@@@@'+val['videoRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['videoRenderer']['videoId']
               
             
             image=val['videoRenderer']['thumbnail']['thumbnails'][0]['url']
             if 'simpleText' in val['videoRenderer']['title']:
             
                name=val['videoRenderer']['title']['simpleText']
             else:
                name=val['videoRenderer']['title']['runs'][0]['text']
             if 'videoCountText' in val['videoRenderer']:
               plot=val['videoRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         addLink( name, playid,3,False, image,plot)
    
def main_menu():
    #check_youtuedl()
    html=read_site_html('https://www.youtube.com/')
    
  
    regex='var ytInitialGuideData = (.+?);'
    match=re.compile(regex,re.DOTALL).findall(html)
    json_data=json.loads(match[0])
    for val in json_data['items']:
     if 'guideSectionRenderer' in val :
      
          for value in val['guideSectionRenderer']['items']:
            if  'navigationEndpoint' in value['guideEntryRenderer']:
                name=value['guideEntryRenderer']['title']
              
                link='https://www.youtube.com/'+value['guideEntryRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
                
                if "settings" not in name.lower()   and "channels" not in  name.lower() and "history" not in  name.lower() :
                  addDir3(name,link,2,'','',name)
    addDir3('Search','www',5,' ',' ','search')



def get_directlink(url):
     import requests
     '''
     from youtube import cHoster
     hote = cHoster()
     hote.setUrl(url)
     stream_url = hote.getMediaLink()[1]
     logging.warning(stream_url)
  
     import YDStreamExtractor
     vid = YDStreamExtractor.getVideoInfo(url,quality=2,resolve_redirects=True) #quality is 0=SD, 1=720p, 2=1080p and is a maximum

     if vid==None:
      return 'NONE'
     stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
     logging.warning(stream_url)
     
     from pytube import YouTube
   
    
     stream_url = YouTube(url).streams.first().download()
     '''
     url=url.replace('/watch?v=/watch?v=','/watch?v=')
     listen_port=Addon.getSetting("port")
     #listen_port='8080'
     data={'url':url,
        
           }
     event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
     
     if event['url']=='None':
        xbmcgui.Dialog().ok('Error','Not aviable')
        sys.exit()
     if event['type']=='m3u8':
        stream_url=event['url']
     else:
        
        stream_url='http://127.0.0.1:%s/'%listen_port+event['url']
     if  not (xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')):
        stream_url=event['url']
     data={}
     try:
        data=json.loads(event['data'])
     except:
        pass
     return stream_url,data
def populate (url,playlist,x,name):
         '''
         import YDStreamExtractor
         link= YDStreamExtractor.getVideoInfo(url,quality=2)
         
         stream_url = link.streamURL()
         '''
    
         #from pytube import YouTube
         #stream_url = YouTube(url).streams.first().download()
         stream_url='plugin://plugin.video.MyYoutube/?action=play_video&videoid=%s'%url.replace('https://www.youtube.com//watch?v=','')
         listitem =xbmcgui.ListItem (name, thumbnailImage=' ')
         listitem.setInfo('video', {'Title': name})
         playlist.add(url=stream_url, listitem=listitem, index=x)
 
def load_test_data(title,icon,fanart,plot,s_title,season,episode,list):
    test_episode = {"episodeid": 0, "tvshowid": 0, "title": title, "art": {}}
    test_episode["art"]["tvshow.poster"] = icon
    test_episode["art"]["thumb"] = icon
    test_episode["art"]["tvshow.fanart"] = fanart
    test_episode["art"]["tvshow.landscape"] =fanart
    test_episode["art"]["tvshow.clearart"] = fanart
    test_episode["art"]["tvshow.clearlogo"] = icon
    test_episode["plot"] = plot
    test_episode["showtitle"] =s_title
    test_episode["playcount"] = 1
    test_episode["season"] =int( season)
    test_episode["episode"] = int(episode)
    test_episode["seasonepisode"] = ''
    test_episode["rating"] = None
    test_episode["firstaired"] = ""
    test_episode["list"]=list
    return test_episode
def calculate_progress_steps(period):
        return (100.0 / int(period)) / 10
def play_video(name,url):
    import requests
    global list_index
    logging.warning('url:'+url)
    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': '%s;q=0.8,en-US;q=0.5,en;q=0.3'%lang,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    id=url.split("@@@@")[1]
    if url.split("@@@@")[0]=="playlistId" and 'watch' not in id:
        lk='https://www.youtube.com/playlist?list='+id
        x=requests.get(lk,headers=headers).content
        regex='https://i.ytimg.com/vi/(.+?)/'
        
        id=re.compile(regex).findall(x)[0]
        url='playlistId@@@@watch?v='+id+'&list='+url.split("@@@@")[1]
   
    lk='https://www.youtube.com/watch?v='+id
    link,data=get_directlink(lk)
    logging.warning(link)
    if data=={}:
        data={"Title": name}
    listItem = xbmcgui.ListItem(name, path=link) 
    if '127.0.0.1' in link and (xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')):
        listItem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        listItem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    else:
        listItem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    logging.warning('Playing')
    listItem.setInfo(type='Video', infoLabels=data)
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)

    if url.split("@@@@")[0]=="playlistId":
       html=read_site_html('https://www.youtube.com/'+url.split("@@@@")[1])

       logging.warning('https://www.youtube.com/'+url.split("@@@@")[1])
       regex='"ytInitialData".+?= (.+?)};'
       match=re.compile(regex,re.DOTALL).findall(html)

       json_data=json.loads(match[0]+'}')
       
       playlist =xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
       playlist.clear()
       x=0
       for value in json_data['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']:
         
         link_b=value['playlistPanelVideoRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
         if 'title' in value['playlistPanelVideoRenderer']:
            name=value['playlistPanelVideoRenderer']['title']['simpleText']
         else:
            continue
         
         threading.Thread(target=populate, args=('https://www.youtube.com/'+link_b,playlist,x,name )).start()
         x=x+1
         
    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': '%s;q=0.8,en-US;q=0.5,en;q=0.3'%lang,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    x=requests.get('https://www.youtube.com/watch?v='+id,headers=headers).content
    regex='"ytInitialData"] = {(.+?)};'
    m=re.compile(regex).findall(x)
    all_d=json.loads('{'+m[0]+'}')
    list=[]
    list_img=[]
    all_p=[]
    all_links=[]
    logging.warning(json.dumps(all_d))
    try:
        in_next=all_d['contents']['twoColumnWatchNextResults']['secondaryResults']['secondaryResults']['results']
        
    except:
        in_next=[]
        pass
    for items in in_next:
        
        if 'compactVideoRenderer' in items:
            title=items['compactVideoRenderer']['title']['simpleText']
            img=items['compactVideoRenderer']['thumbnail']['thumbnails'][0]['url']
            
            plot=items['compactVideoRenderer']['title']['accessibility']['accessibilityData']['label']
            link=items['compactVideoRenderer']['videoId']
            all_p.append(plot)
            list.append(title)
            list_img.append(img)
            all_links.append(link)
            
            
    before_end=int(Addon.getSetting("before_end2"))
    show_window=False
    counter=0
    while xbmc.Player().isPlaying():
        try:
            vidtime = xbmc.Player().getTime()
        except:
            vidtime=0
        try:
            time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            time_left=99999999
        if time_left<(before_end+1) and time_left>0:
            logging.warning('Time left')
            logging.warning(time_left)
            logging.warning(before_end)
            show_window=True
            break
        xbmc.sleep(500)
    
    if show_window:
        next_up_page = UpNext("script-upnext-upnext.xml",Addon.getAddonInfo('path'), "DefaultSkin", "1080i")

        ep=load_test_data(list[0],list_img[0],list_img[0],list[0],list[0],'0','0',list)
        
        next_up_page.setItem(ep)

        next_up_page.setProgressStepSize(calculate_progress_steps(30))
        next_up_page.doModal()
        del next_up_page
    if Addon.getSetting("auto_play_next")=='true':
        if list_index!=888 and list_index!=111:
            if list_index==999:
                list_index=0
            logging.warning('Play next')
            logging.warning(all_links[list_index])
            
            lk='plugin://plugin.video.MyYoutube/?url=videoid%40%40%40%40{0}&mode=3&name={1}'.format(all_links[list_index], list[list_index])
            logging.warning(lk)
            xbmc.Player().stop()
            xbmc.executebuiltin('XBMC.PlayMedia("%s")'%lk)
            #xbmc.executebuiltin('XBMC.RunPlugin(%s)'%lk)
            list_index=111
    else:
        if list_index!=888 and list_index!=111 :
            
            lk='plugin://plugin.video.MyYoutube/?url=videoid%40%40%40%40{0}&mode=3&name={1}'.format(all_links[list_index], list[list_index])
            xbmc.Player().stop()
            xbmc.executebuiltin('XBMC.PlayMedia(%s)'%lk)
            list_index=111


       

def search_results(name,url,plot):
    file_data=[]
    
    if os.path.exists(save_file):
            f = open(save_file, 'r')
            file_data = f.readlines()
            f.close()
    if 'search' in plot and "page" not in name:
        if name=='search':
          search_entered =''
        
          keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
          keyboard.doModal()
          if keyboard.isConfirmed():
                    search_entered = keyboard.getText()
          if search_entered not in file_data:
            file_data.append(search_entered)
            file = open(save_file, 'w')
            file.write('\n'.join(file_data))
            file.close()
        else:
          search_entered=name
          
          

          
        if search_entered !='' :
          url='https://www.youtube.com/results?search_query='+search_entered.replace(' ','+')

    html=read_site_html(url)
  
    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(html)
   

    json_data=json.loads(match[0]+'}')
 

    for value in json_data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents']:
       
       if 'videoRenderer' in value:
         link='videoid@@@@'+value['videoRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
         
         if 'simpleText' in value['videoRenderer']['title']:
            name=value['videoRenderer']['title']['simpleText']
         else:
            name=value['videoRenderer']['title']['runs'][0]['text']
         image=value['videoRenderer']['thumbnail']['thumbnails'][0]['url']
         plot=value['videoRenderer']['title']['accessibility']['accessibilityData']['label']
         addLink( name, link,3,False, image,plot)
       elif 'radioRenderer' in value :
         link='playlistId@@@@'+value['radioRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
         name=value['radioRenderer']['title']['simpleText'] 
         image=value['radioRenderer']['thumbnail']['thumbnails'][0]['url']
         plot=value['radioRenderer']['videoCountText']['runs'][0]['text']
         addLink( name, link,3,False, image,plot)
       elif 'playlistRenderer' in value :
         link='playlistId@@@@'+value['playlistRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
         name=value['playlistRenderer']['title']['simpleText'] 
         image=value['playlistRenderer']['thumbnails'][0]['thumbnails'][0]['url']
         plot=value['playlistRenderer']['videoCountText']['runs'][0]['text']
         addLink( name, link,3,False, image,plot)
    
    if 'page=' in url:
      next_page=url.split('page=')
      next=next_page[0]+'page='+str(int(next_page[1])+1)
    else:
      next=url+'&page='+str(2)
    addDir3('[COLOR aqua][I][B]Next[/B][/I][/COLOR]',next,4,'','','Next')
def check_youtuedl():
   from shutil import copyfile
   you_Addon = xbmcaddon.Addon(id='script.module.youtube.dl')
   you_addonPath = xbmc.translatePath(you_Addon.getAddonInfo("path")).decode("utf-8")
   libDir = os.path.join(you_addonPath,  'lib','YoutubeDLWrapper.py')

   file = open(libDir,'r').read()
   if '#if xbmc.abortRequested:' not in file:
    libDir2 = os.path.join(addonPath,'YoutubeDLWrapper.py')
    copyfile(libDir2, libDir)

def search_with_hist():
     file_data=[]
     if os.path.exists(save_file):
            f = open(save_file, 'r')
            file_data = f.readlines()
            f.close()
     for names in file_data:
        addDir3(names,'www',4,' ',' ','search')
     addDir3('search','www',4,' ',' ','search')
def remove_one(name):
    file_data=[]
    change=0

    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
 
    if name.decode('utf8') in file_data:

      file_data.pop(file_data.index(name.decode('utf8') ))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
    xbmc.executebuiltin('Container.Refresh')
def pop_list(url):
    html=read_site_html(url)

       
    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(html)

    json_data=json.loads(match[0]+'}')
   
   
    x=0
    for value in json_data['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']:
     
      link_b='videoid@@@@'+value['playlistPanelVideoRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
      if 'title' in value['playlistPanelVideoRenderer']:
         name=value['playlistPanelVideoRenderer']['title']['simpleText']
      else:
         continue
      
      image=value['playlistPanelVideoRenderer']['thumbnail']['thumbnails'][0]['url']
      addLink( name, link_b,3,False, image,' ')
def get_x(url):
    refer=url.split('@@@@')[0]
    o_url=refer
    ctoken=url.split('@@@@')[2]
    itct=url.split('@@@@')[3]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0',
        'Accept': '*/*',
        'Accept-Language': '%s,en;q=0.5'%lang,
        'Referer': refer,
        'X-YouTube-Client-Name': '1',
        'X-YouTube-Client-Version': '2.20200229.10.00',
        'X-YouTube-Device': 'cbr=Firefox&cbrver=73.0&cos=Windows&cosver=10.0',
        
        
        
        'X-SPF-Referer': refer,
        'X-SPF-Previous': refer,
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }

    params = (
        ('ctoken', ctoken),
        ('continuation', ctoken),
        ('itct', itct),
    )

    response = requests.get('https://www.youtube.com/browse_ajax', headers=headers, params=params).json()[1]
    for val in response['response']['continuationContents']['gridContinuation']['items']:
                     if 'gridPlaylistRenderer' in val:
                         if 'playlistId' in val['gridPlaylistRenderer']:
                           
                           playid='playlistId@@@@'+val['gridPlaylistRenderer']['playlistId']
                           playlist_pl='Playlist'
                         else:
                           playlist_pl=''
                           playid='videoid@@@@'+val['gridPlaylistRenderer']['videoId']
                         
                         image=val['gridPlaylistRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridPlaylistRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['gridPlaylistRenderer']:
                           plot=val['gridPlaylistRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                         plot=playlist_pl+'\n'+plot
                     elif 'gridRadioRenderer' in val :
                         if 'playlistId' in val['gridRadioRenderer']:
                           
                           playid='playlistId@@@@'+val['gridRadioRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridRadioRenderer']['videoId']
                         
                         image=val['gridRadioRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridRadioRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridRadioRenderer']:
                           plot=val['gridRadioRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'gridVideoRenderer' in val:
                         if 'playlistId' in val['gridVideoRenderer']:
                           
                           playid='playlistId@@@@'+val['gridVideoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridVideoRenderer']['videoId']
                         
                         image=val['gridVideoRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridVideoRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridVideoRenderer']:
                           plot=val['gridVideoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'videoRenderer' in val:
                         if 'playlistId' in val['videoRenderer']:
                           
                           playid='playlistId@@@@'+val['videoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['videoRenderer']['videoId']
                           
                         
                         image=val['videoRenderer']['thumbnail']['thumbnails'][0]['url']
                         if 'simpleText' in val['videoRenderer']['title']:
                         
                            name=val['videoRenderer']['title']['simpleText']
                         else:
                            name=val['videoRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['videoRenderer']:
                           plot=val['videoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     
                        
                     addLink( name, playid,3,False, image,plot)
    if 'continuations' in response['response']['continuationContents']['gridContinuation']:
        url=o_url+'@@@@next'+'@@@@'+response['response']['continuationContents']['gridContinuation']['continuations'][0]['nextContinuationData']['continuation']+'@@@@'+response['response']['continuationContents']['gridContinuation']['continuations'][0]['nextContinuationData']['clickTrackingParams']
        addDir3('[COLOR aqua][I][B]Next[/B][/I][/COLOR]',url,8,'','','Next')
            
    
    
def get_user_list(url):
    o_url=url
    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': '%s;q=0.8,en-US;q=0.5,en;q=0.3'%lang,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    if 'next'+'@@@@' in url:
        x=get_x(url)
        return 0
    else:
        x=requests.get(url,headers=headers).content
    regex='"ytInitialData"] = {(.+?)};'
    m=re.compile(regex).findall(x)
    all_d=json.loads('{'+m[0]+'}')
    for items in all_d['contents']['twoColumnBrowseResultsRenderer']['tabs']:
        if 'tabRenderer' in items:
            nm=items['tabRenderer']['title'].decode('utf-8')
            lk='https://www.youtube.com'+items['tabRenderer']['endpoint']['commandMetadata']['webCommandMetadata']['url'].encode('utf-8')
            
            addDir3(nm,lk,8,' ',' ',nm)
    for ttx in all_d['contents']['twoColumnBrowseResultsRenderer']['tabs']:
      if 'tabRenderer' in ttx:
       if 'content' in ttx['tabRenderer']:
        for items in ttx['tabRenderer']['content']['sectionListRenderer']['contents']:
            logging.warning('In items')
            name=''
            cat=items['itemSectionRenderer']['contents'][0]
            
            if 'gridRenderer' in cat:
                for val in cat['gridRenderer']['items']:
                     if 'gridPlaylistRenderer' in val:
                         if 'playlistId' in val['gridPlaylistRenderer']:
                           
                           playid='playlistId@@@@'+val['gridPlaylistRenderer']['playlistId']
                           playlist_pl='Playlist'
                         else:
                           playlist_pl=''
                           playid='videoid@@@@'+val['gridPlaylistRenderer']['videoId']
                         
                         image=val['gridPlaylistRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridPlaylistRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['gridPlaylistRenderer']:
                           plot=val['gridPlaylistRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                         plot=playlist_pl+'\n'+plot
                     elif 'gridRadioRenderer' in val :
                         if 'playlistId' in val['gridRadioRenderer']:
                           
                           playid='playlistId@@@@'+val['gridRadioRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridRadioRenderer']['videoId']
                         
                         image=val['gridRadioRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridRadioRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridRadioRenderer']:
                           plot=val['gridRadioRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'gridVideoRenderer' in val:
                         if 'playlistId' in val['gridVideoRenderer']:
                           
                           playid='playlistId@@@@'+val['gridVideoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridVideoRenderer']['videoId']
                         
                         image=val['gridVideoRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridVideoRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridVideoRenderer']:
                           plot=val['gridVideoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'videoRenderer' in val:
                         if 'playlistId' in val['videoRenderer']:
                           
                           playid='playlistId@@@@'+val['videoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['videoRenderer']['videoId']
                           
                         
                         image=val['videoRenderer']['thumbnail']['thumbnails'][0]['url']
                         if 'simpleText' in val['videoRenderer']['title']:
                         
                            name=val['videoRenderer']['title']['simpleText']
                         else:
                            name=val['videoRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['videoRenderer']:
                           plot=val['videoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     
                        
                     addLink( name, playid,3,False, image,plot)
                if 'continuations' in cat['gridRenderer']:
                    url=o_url+'@@@@next'+'@@@@'+cat['gridRenderer']['continuations'][0]['nextContinuationData']['continuation']+'@@@@'+cat['gridRenderer']['continuations'][0]['nextContinuationData']['clickTrackingParams']
                    addDir3('[COLOR aqua][I][B]Next[/B][/I][/COLOR]',url,8,'','','Next')
            elif 'channelVideoPlayerRenderer' in cat:
                name=cat['channelVideoPlayerRenderer']['title']['runs'][0]['text']
                url='videoid@@@@'+cat['channelVideoPlayerRenderer']['videoId']
                plot=cat['channelVideoPlayerRenderer']['description']['runs'][0]['text']
              
                addLink( name, url,3,False, ' ',' ')
            else:
                if 'shelfRenderer' in cat:
                    name_no_link=cat['shelfRenderer']['title']['runs'][0]['text']
                    addNolink( name_no_link, 'www',99,False)
                for val in cat['shelfRenderer']['content']['horizontalListRenderer']['items']:
                     if 'gridPlaylistRenderer' in val:
                         if 'playlistId' in val['gridPlaylistRenderer']:
                           
                           playid='playlistId@@@@'+val['gridPlaylistRenderer']['playlistId']
                           playlist_pl='Playlist'
                         else:
                           playlist_pl=''
                           playid='videoid@@@@'+val['gridPlaylistRenderer']['videoId']
                         
                         image=val['gridPlaylistRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridPlaylistRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['gridPlaylistRenderer']:
                           plot=val['gridPlaylistRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                         plot=playlist_pl+'\n'+plot
                     elif 'gridRadioRenderer' in val :
                         if 'playlistId' in val['gridRadioRenderer']:
                           
                           playid='playlistId@@@@'+val['gridRadioRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridRadioRenderer']['videoId']
                         
                         image=val['gridRadioRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridRadioRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridRadioRenderer']:
                           plot=val['gridRadioRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'gridVideoRenderer' in val:
                         if 'playlistId' in val['gridVideoRenderer']:
                           
                           playid='playlistId@@@@'+val['gridVideoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['gridVideoRenderer']['videoId']
                         
                         image=val['gridVideoRenderer']['thumbnail']['thumbnails'][0]['url']
                         name=val['gridVideoRenderer']['title']['simpleText']
                         if 'videoCountText' in val['gridVideoRenderer']:
                           plot=val['gridVideoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     elif 'videoRenderer' in val:
                         if 'playlistId' in val['videoRenderer']:
                           
                           playid='playlistId@@@@'+val['videoRenderer']['playlistId']
                         else:
                           playid='videoid@@@@'+val['videoRenderer']['videoId']
                           
                         
                         image=val['videoRenderer']['thumbnail']['thumbnails'][0]['url']
                         if 'simpleText' in val['videoRenderer']['title']:
                         
                            name=val['videoRenderer']['title']['simpleText']
                         else:
                            name=val['videoRenderer']['title']['runs'][0]['text']
                         if 'videoCountText' in val['videoRenderer']:
                           plot=val['videoRenderer']['videoCountText']['runs'][0]['text']
                         else:
                           plot=" "
                     
                        
                     addLink( name, playid,3,False, image,plot)
def direct_user_search(url):
    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': '%s;q=0.8,en-US;q=0.5,en;q=0.3'%lang,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    logging.warning(url)
    x=requests.get(url,headers=headers).content
    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(x)

    json_data=json.loads(match[0]+'}')
    
    lk=''
    for ur in json_data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents']:
        if 'channelRenderer' in ur:
            lk='https://www.youtube.com'+ur['channelRenderer']['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
            break
    if lk!='':
        get_user_list(lk)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
action=None
videoid=None

playlist=None
logging.warning(sys.argv)
if 'plugin://plugin.video.MyYoutube/kodion/search/query/' in sys.argv[0]:
    mode=4
    name=sys.argv[2].replace('?q=','').replace('/','')
    description=''
    url='https://www.youtube.com/results?search_query='+sys.argv[2].replace('?q=','').replace('/','')
    
    
if 'plugin://plugin.video.MyYoutube/channel/' in sys.argv[0]:
    mode=8
    name='list'
    url='https://www.youtube.com/channel/'+sys.argv[0].replace('plugin://plugin.video.MyYoutube/channel/','').replace('/','')
    
if 'plugin://plugin.video.MyYoutube/user/' in sys.argv[0]:
    mode=8
    name='list'
    url='https://www.youtube.com/user/'+sys.argv[0].replace('plugin://plugin.video.MyYoutube/user/','').replace('/','')
    
if 'plugin://plugin.video.MyYoutube/playlist/' in sys.argv[0]:
    mode=7
    name='list'
    url='https://www.youtube.com/watch?v=KMh3rO0scX4&list='+sys.argv[0].replace('plugin://plugin.video.MyYoutube/playlist/','').replace('/','')
try:
        action=(params["action"])
except:
        pass

try:
        videoid=(params["videoid"])
except:
      try:
        videoid=(params["video_id"])
      except:
        pass
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass


if videoid!=None:
    mode=3
    url="a@@@@"+videoid
    name='vid'

logging.warning(mode)
if url is not None:
  url=url.replace("@@@@@@","=").replace("*****","&").replace("!!!!!!","?")  

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     pop_youtube_data(name,url)
elif mode==3:
     play_video(name,url)
elif mode==4:
     search_results(name,url,description)
elif mode==5:
     search_with_hist()
elif mode==6:
     remove_one(name)
elif mode==7:
     pop_list(url)
elif mode==8:
    get_user_list(url)
elif mode==10:
    direct_user_search(url)
    
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))


# -*- coding: utf-8 -*-


# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc        
import xbmcaddon 
import xbmcplugin   
import re     
import xbmcgui      

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')    
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"

YOUTUBE_CHANNEL_ID_1 = "PL_OVlzi87KEh0PHi6s7KKEnip9vHOYbNX" #Ben and Holly
YOUTUBE_CHANNEL_ID_2 = "PL_OVlzi87KEiSv1SRNBAUtOcADQAJlKjN" #Detentionaire
YOUTUBE_CHANNEL_ID_3 = "PL_OVlzi87KEhrek_GqlU4W_1y59to5RqB" #He-Man
YOUTUBE_CHANNEL_ID_4 = "PL_OVlzi87KEhxhbxZItRhJ_wPf_3Ok7AY" #Little Einsteins
YOUTUBE_CHANNEL_ID_5 = "PL_OVlzi87KEhH_8YOa0LVf5tpqOcdINDH" #Marvel: Avengers Assemble
YOUTUBE_CHANNEL_ID_6 = "PL_OVlzi87KEg9rD7xyd89W9crCHtC5fKP" #Marvel: Guardians of the Galaxy
YOUTUBE_CHANNEL_ID_7 = "PL_OVlzi87KEjR2gjJnkjG4hfQPsii_d10" #Marvel: Marvel Rising
YOUTUBE_CHANNEL_ID_8 = "PL_OVlzi87KEg09M6_tqx8_wCbGagJKpDq" #Marvel: Super Hero Squad
YOUTUBE_CHANNEL_ID_9 = "PL_OVlzi87KEjsF2fcn0fklEu3of3jPOyA" #Marvel: Ultimate Spider-Man
YOUTUBE_CHANNEL_ID_10 = "PL_OVlzi87KEjWUfqBCFGwuo8SvseqML8n" #Mickey & Minnie
YOUTUBE_CHANNEL_ID_11 = "PL_OVlzi87KEjnDo7AFbr_I1OcIEu7TPB_" #Molly of Denali
YOUTUBE_CHANNEL_ID_12 = "PL_OVlzi87KEh4MqTWhm_zK6QK2CzChrVp" #Peppa Pig
YOUTUBE_CHANNEL_ID_13 = "PL_OVlzi87KEi805q2TZXSVVzb5sdykWEG" #Pinkalicious & Peterrific
YOUTUBE_CHANNEL_ID_14 = "PL_OVlzi87KEh0obtf--bPbmlBkRONyWT-" #PJ Masks
YOUTUBE_CHANNEL_ID_15 = "PL_OVlzi87KEgMezwZZkA_pgNWT1WwVC4L" #Sabrina the Animated Series
YOUTUBE_CHANNEL_ID_16 = "PL_OVlzi87KEheloetWdL1NjClBXOlVjkX" #Sesame Street
YOUTUBE_CHANNEL_ID_17 = "PL_OVlzi87KEjp0DO74QFByx89xl9bUi_u" #Underdog
YOUTUBE_CHANNEL_ID_18 = "PL_OVlzi87KEh2I8evalgu3H-QoAHIBSaj" #Voltron: Defenders of the Universe
YOUTUBE_CHANNEL_ID_19 = "PL_OVlzi87KEjJ0_yh7T_td2ZVEfmsZtqf" #Voltron Force


@route(mode='main_menu') 
def Main_Menu():
	Add_Dir( 
        name="Ben and Holly's Little Kingdom", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mAeD4hCRuAnlyoO7IoY1ReJsV0OMasVrzUG0g=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Detentionaire", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BYWQ2MjBkZWItMjU2YS00MzE5LTkzYzEtN2QxOTQ2YjM4NDJiXkEyXkFqcGdeQXVyNDQ2OTk4MzI@._V1_UY268_CR0,0,182,268_AL_.jpg")
		
	Add_Dir( 
        name="He-Man and the Masters of the Universe", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://image.tmdb.org/t/p/original/5lcbl0p7fGjrrwSXpeK2cqss0MV.jpg")
		
	Add_Dir( 
        name="Little Einsteins", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w500_and_h282_face/14vgR5tU2VWXAX6Xh4tw13jdajH.jpg")
		
	Add_Dir( 
        name="Marvel: Avengers Assemble", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BMTY0NTUyMDQwOV5BMl5BanBnXkFtZTgwNjAwMTA0MDE@._V1_SY1000_CR0,0,745,1000_AL_.jpg")
		
	Add_Dir( 
        name="Marvel: Guardians of the Galaxy", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BNDM4NDQxMDU2MV5BMl5BanBnXkFtZTgwMDY2MDQ5NjE@._V1_SY1000_CR0,0,650,1000_AL_.jpg")
		
	Add_Dir( 
        name="Marvel: Marvel Rising", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BYjQzNDJiMTgtODhiMi00NWJlLTllMjAtNTA3MzJmOWVmMDNiXkEyXkFqcGdeQXVyODQyNDI4ODg@._V1_.jpg")
		
	Add_Dir( 
        name="Marvel: Super Hero Squad", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BYzc3ODBiNWItYTA2Zi00YmVlLWFjMzgtZjk4YWFlZjMxZDdlXkEyXkFqcGdeQXVyNjExODE1MDc@._V1_.jpg")
		
	Add_Dir( 
        name="Marvel: Ultimate Spider-Man", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BMDg5NTFlMTUtNDdmYi00MGYwLTlkNjQtMjU2NzEzMDFhMDY3XkEyXkFqcGdeQXVyNjExODE1MDc@._V1_SY1000_CR0,0,704,1000_AL_.jpg")
		
	Add_Dir( 
        name="Mickey & Minnie Mouse", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w500_and_h282_face/jxbHld2sKroi9y5VMIlTJ7to9SS.jpg")
		
	Add_Dir( 
		name="Molly of Denali",url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
		icon="https://m.media-amazon.com/images/M/MV5BNjY0ODU5OTctOWJlZi00ZTEyLWJiYTUtYzEyNzEyNjliOTg0XkEyXkFqcGdeQXVyMjg1NTQ1NzY@._V1_.jpg")
	
	Add_Dir( 
		name="Peppa Pig",url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mA70LJHFeabrZd2uABvShclmSZFVYveSIUUpg=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
		name="Pinkalicious & Peterrific",url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
		icon="https://m.media-amazon.com/images/M/MV5BOTY3M2YwZDctN2IxNC00OTA4LWIyMzYtYWZlNDk0NTA0MTAyXkEyXkFqcGdeQXVyMjg1NTQ1NzY@._V1_.jpg")
	
	Add_Dir( 
        name="PJ Masks", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mAj1QPlp4LK7YIblqjNusi6_xv5OllZz4AKrg=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Sabrina the Animated Series", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BMTU5NTEzMjY1OV5BMl5BanBnXkFtZTcwNzk2NjUzMQ@@._V1_UY268_CR4,0,182,268_AL_.jpg")
	
	Add_Dir( 
        name="Sesame Street", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mD_J51bh-SUytT7QcA5nRVYz40BySOh-UzGRA=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Underdog TV Series, 1964", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w130_and_h195_bestv2/d1Mc2GQsh5GtsLmHHCrbER4QDkI.jpg")		
	
	Add_Dir( 
        name="Voltron: Defender of the Universe", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BZDUyNGFiM2QtMzFkMC00YjhjLTk3NjktYmMwZDY1Njg2OTZjXkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SY1000_CR0,0,703,1000_AL_.jpg")
		
	Add_Dir( 
        name="Voltron Force", url=BASE+YOUTUBE_CHANNEL_ID_19+"/", folder=True,
        icon="https://m.media-amazon.com/images/M/MV5BMTcxOTA2MDcwNV5BMl5BanBnXkFtZTcwOTcwNjMyNw@@._V1_SY1000_CR0,0,647,1000_AL_.jpg")
		
		
		
		
		
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
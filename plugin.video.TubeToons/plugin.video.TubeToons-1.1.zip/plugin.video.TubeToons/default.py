# -*- coding: utf-8 -*-


# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc        
import xbmcaddon 
import xbmcplugin   
import re     
import xbmcgui      

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')    
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PL_OVlzi87KEi3ovEv3FJL9dIhilBDqMO7" #Live Streaming
YOUTUBE_CHANNEL_ID_2 = "PL_OVlzi87KEh0PHi6s7KKEnip9vHOYbNX" #Ben and Holly
YOUTUBE_CHANNEL_ID_3 = "PL_OVlzi87KEhxhbxZItRhJ_wPf_3Ok7AY" #Little Einsteins
YOUTUBE_CHANNEL_ID_4 = "PL_OVlzi87KEjWUfqBCFGwuo8SvseqML8n" #Mickey & Minnie
YOUTUBE_CHANNEL_ID_5 = "PL_OVlzi87KEh4MqTWhm_zK6QK2CzChrVp" #Peppa Pig
YOUTUBE_CHANNEL_ID_6 = "PL_OVlzi87KEh0obtf--bPbmlBkRONyWT-" #PJ Masks
YOUTUBE_CHANNEL_ID_7 = "PL_OVlzi87KEheloetWdL1NjClBXOlVjkX" #Sesame Street
YOUTUBE_CHANNEL_ID_8 = "PL_OVlzi87KEjp0DO74QFByx89xl9bUi_u" #Underdog


@route(mode='main_menu') 
def Main_Menu():
	Add_Dir( 
        name="Live Streaming Cartoons", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://raw.githubusercontent.com/Incendiary-Pyro/zips/master/plugin.video.TubeToons/live.png")
		
	Add_Dir( 
        name="Ben and Holly's Little Kingdom", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mAeD4hCRuAnlyoO7IoY1ReJsV0OMasVrzUG0g=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Little Einsteins", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w500_and_h282_face/14vgR5tU2VWXAX6Xh4tw13jdajH.jpg")
		
	Add_Dir( 
        name="Mickey & Minnie Mouse", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w500_and_h282_face/jxbHld2sKroi9y5VMIlTJ7to9SS.jpg")
	
	Add_Dir( 
		name="Peppa Pig",url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mA70LJHFeabrZd2uABvShclmSZFVYveSIUUpg=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="PJ Masks", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mAj1QPlp4LK7YIblqjNusi6_xv5OllZz4AKrg=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Sesame Street", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mD_J51bh-SUytT7QcA5nRVYz40BySOh-UzGRA=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Underdog TV Series, 1964", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://image.tmdb.org/t/p/w130_and_h195_bestv2/d1Mc2GQsh5GtsLmHHCrbER4QDkI.jpg")		
		
		
		
		
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
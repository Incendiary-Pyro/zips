# -*- coding: utf-8 -*-


# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)


import os           
import xbmc        
import xbmcaddon 
import xbmcplugin   
import re     
import xbmcgui      

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File



debug        = Addon_Setting(setting='debug')    
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PL_OVlzi87KEjuurnAJbf87AQKZrDVBlqt" #2Cellos
YOUTUBE_CHANNEL_ID_2 = "PL_OVlzi87KEiDDqJ25IFM9SM7OgoGZ6eT" #Amadeus
YOUTUBE_CHANNEL_ID_3 = "PL_OVlzi87KEgv1zZfCrBUKzM3SV5TFBqi" #Camille
YOUTUBE_CHANNEL_ID_4 = "PL_OVlzi87KEgitnxWyfgyAHpXUUvbCy15" #Catlin De Ville
YOUTUBE_CHANNEL_ID_5 = "PL_OVlzi87KEg7mo2Vp7J8ZavhPbPM0Wa4" #Celtic
YOUTUBE_CHANNEL_ID_6 = "PL_OVlzi87KEjUAwC20ZlLZnKgObXqVb8t" #Daniel Jang
YOUTUBE_CHANNEL_ID_7 = "PL_OVlzi87KEiCRdgZ_uLaTeXAc5fb9agB" #Marion
YOUTUBE_CHANNEL_ID_8 = "PL_OVlzi87KEgsR-IDHGe_S4Y_WAbR1eys" #Karolina
YOUTUBE_CHANNEL_ID_9 = "PL_OVlzi87KEgC-SnoktGQ9GJOpvlRs5zC" #Lindsey
YOUTUBE_CHANNEL_ID_10 = "PL_OVlzi87KEgff--6K8lP3kOjamXCFaAI" #Patty
YOUTUBE_CHANNEL_ID_11 = "PL_OVlzi87KEj3rXc5HxHrqRpBV2mE5JoO" #Taylor


@route(mode='main_menu') #For Icon make sure you use 256x256 Jpg URL goes in there
def Main_Menu():
	Add_Dir( 
		name="2 Cellos", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mDxdbfYIIbGuG5f3F5Pkqg8AiqVsxadG62Qzg=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Amadeus Electric Quartet", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mD_h-LMmsaiR-1MKbhA1Fvq_D02vpAWr1-FDw=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Camille and Kennerly", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mD3mi0afHAlLG9mkQ8vv-4SSnbhGI7okbv2BQ=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Catlin De Ville", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mCBXXvYhLGRNF3A-4xDkGGkal83suE3qOFhvg=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Celtic Woman", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mDwXzfhbsclS69WSYDo50JWfxX7eWLwc21_-A=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Daniel Jang", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mCBEOLLWz5zHRlODDn2TQi3yf8wdSX-BjvweQ=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Marion", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mCJMJ6Rbzg6bc0clq-pSk7WYqCnOC2QOoqUng=s288-mo-c-c0xffffffff-rj-k-no")
		
	Add_Dir( 
        name="Karolina Protsenko", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mBSzvWf_wGukIBaZWWcZsb2UIYo7lRbMMLvHw=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Lindsey Stirling", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mD85GeeM4yI5bHF4JhxCdQA99GjWoQk486_=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
        name="Patty Gurdy", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AAuE7mDiOHykJ-1b1K3unz831EporRPkFXBsIB2CMQ=s288-mo-c-c0xffffffff-rj-k-no")
	
	Add_Dir( 
		name="Taylor Davis", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
		icon="https://yt3.ggpht.com/a-/AAuE7mC9saDrlJX-hbXTdLLKxpV9RZAsLhTfj3cjPw=s288-mo-c-c0xffffffff-rj-k-no")
		
		
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))